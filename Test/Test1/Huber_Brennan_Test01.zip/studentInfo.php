<!DOCTYPE php>
<!--	Author:   Brennan Huber
		Date:  	 October 10, 2017
		File:	    studentInfo.php
		Purpose:  Test01
-->

<html>
<head>
	<title>StudentInfo</title>
</head>
<body>
	<form action="studentInfo.html">
   	<input type="submit" value="Start Page" />
	</form>

	<?php
      $f_name = $_POST['f_name'];
      $l_name = $_POST['l_name'];
      $utc_id = $_POST['utc_id'];
      $gpa = $_POST['gpa'];

		$f_name = ucfirst(strtolower($f_name));
		$l_name = ucfirst(strtolower($l_name));
		$utc_id = ucfirst(strtolower($utc_id));

      $ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
      $NUMBERS = "0123456789";

      // checking first and last name length
      if(strlen($f_name) > 15 || strlen($f_name) == 0 || strlen($l_name) > 15 || strlen($l_name) == 0)
      {
         printError("First or last name");
         return;
      }

      // making sure there are only letters in the names
      for($i = 0; $i < strlen($f_name); $i++)
      {
         if(strpos($ALPHABET, substr($f_name, $i, 1)) === false)
         {
            printError("First name");
            return;
         }
      }
      for($i = 0; $i < strlen($l_name); $i++)
      {
         if(strpos($ALPHABET, substr($l_name, $i, 1)) === false)
         {
            printError("Last name");
            return;
         }
      }

      // checking the UTC id
		if(strlen($utc_id) != 6)
		{
			printError("UTC ID");
			return;
		}
      for($i = 0; $i < 3; $i++)
      {
         if(strpos($ALPHABET, substr($utc_id, $i, 1)) === false)
         {
            printError("UTC ID");
            return;
         }
      }
      for($i = 3; $i < 6; $i++)
      {
         if(strpos($NUMBERS, substr($utc_id, $i, 1)) === false)
         {
            printError("UTC ID");
            return;
         }
      }

      // checking GPA
      if(strlen($gpa) != 3)
      {
         printError("GPA");
         return;
      }
      if(strcmp(".", substr($gpa, 1, 1)) != 0)
      {
         printError("GPA");
         return;
      }
      else
      {
         $a = explode(".", $gpa);
         if(strpos($NUMBERS, $a[0]) === false || strpos($NUMBERS, $a[1]) === false)
         {
            printError("GPA");
            return;
         }
      }

      // need to put this info into the correct format.
      $formatted = $l_name .":". $f_name .":". $utc_id .":". $gpa;

      // need to load in the text file.
      $student_arr = readF();

      // add this one to the array of students.
      $student_arr[$utc_id] = $formatted;

      // sort by last name (by value)
      asort($student_arr, $sort_flags = SORT_STRING);

      // output to screen (displayed using a table) and textfile.
      outputText($student_arr);
      outputHTML($student_arr);

      // Function to read in the file. returns array of info
      function readF()
      {
         $file = fopen('studentInfo.txt', 'r');
         $arr = array();

         while(($line = fgets($file)) != false)
         {
      			// cutting off the end line character
      			$line = substr($line, 0, strlen($line) - 1);
               $id = getUTCid($line);

               $arr[$id] = $line;
         }

         fclose($file);
         return $arr;
      }

      function outputText($arr)
      {
         $file = fopen('studentInfo.txt', 'w+');

         foreach($arr as $val)
         {
            fwrite($file, $val . "\n");
         }

         fclose($file);
      }

      function outputHTML($arr)
      {
         print("<table border=\"1\">");
            print("<th>First Name</th>");
            print("<th>Last Name</th>");
            print("<th>UTC ID</th>");
            print("<th>GPA</th>");

            foreach($arr as $val)
            {
               $s = explode(":", $val);
               print("<tr>");
                  print("<td>$s[0]</td>");
                  print("<td>$s[1]</td>");
                  print("<td>$s[2]</td>");
                  print("<td>$s[3]</td>");
               print("</tr>");
            }

         print("</table>");
      }

      function getUTCid($s)
      {
         $arr = explode(":", $s);
         return $arr[2];
      }

      function printError($s)
      {
         print("<h1>Error: $s  incorrect formatting.</h1>");
      }
	?>

</body>
</html>
